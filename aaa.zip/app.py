from flask import Flask, render_template, redirect, request

from data import db_session

from forms import Developer

app = Flask(__name__)
app.config["SECRET_KEY"] = "skinkinkatoonbaton"


@app.route("/", methods=["POST", "GET"])
def show_base_template():
    return render_template("start_page.html")


# Rikudō Sennin Mode
@app.route("/saninmod", methods=["GET", "POST"])
def turn_on_sanin_mod():
    loader = Developer()
    return render_template("developer_mod.html", requester=loader)


@app.route("/EGE")
def show_EGE():
    return render_template("EGE.html")


@app.route("/OGE")
def show_OGE():
    return render_template("OGE.html")


@app.route("/<index>", methods=["POST"])
def choose_class(index):
    print(index)
    return render_template(f"{index} class.html")


def main():
    db_session.global_init("db/EGE.db")
    app.run(debug=True)


if __name__ == "__main__":
    main()
