from flask import render_template
def turn_on_sanin_mode():
    return render_template("")