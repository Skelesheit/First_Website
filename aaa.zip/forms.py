from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, SubmitField, IntegerField
from wtforms.validators import DataRequired


class Developer(FlaskForm):
    name = StringField("name", validators=[DataRequired()])
    type_number = IntegerField("номер задания", validators=[DataRequired()])

    submit = SubmitField('Войти')